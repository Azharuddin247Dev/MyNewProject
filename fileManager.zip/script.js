const ADD_PASSWORD = "admin123";
    const DELETE_PASSWORD = "123admin";

    function loadData() {
      const data = localStorage.getItem("fileData");
      return data ? JSON.parse(data) : [];
    }

    function saveData(data) {
      localStorage.setItem("fileData", JSON.stringify(data));
    }

    function toggleAddForm() {
      document.getElementById("addForm").classList.toggle("hidden");
    }

    function showAddPassword() {
      document.getElementById("addPasswordSection").classList.remove("hidden");
    }

    function confirmAddFile() {
      const pw = document.getElementById("addPassword").value;
      if (pw !== ADD_PASSWORD) {
        alert("❌ Incorrect password");
        return;
      }
      const fileName = document.getElementById("fileName").value.trim();
      const fileCode = document.getElementById("fileCode").value.trim();
      const almirah = document.getElementById("almirahInput").value.trim();
      const shelf = document.getElementById("shelfCode").value.trim();

      if (!fileName || !fileCode || !almirah || !shelf) {
        alert("❗ All fields are required.");
        return;
      }

      const data = loadData();
      data.push({ file_name: fileName, file_code: fileCode, almirah, shelf_code: shelf });
      saveData(data);
      alert("✅ File added.");
      document.querySelectorAll("#addForm input").forEach(i => i.value = "");
      document.getElementById("addPasswordSection").classList.add("hidden");
      renderFiles();
    }

    function loadFileToEdit() {
      const code = document.getElementById("editSearch").value.trim();
      const data = loadData();
      const file = data.find(f => f.file_code === code);

      if (!file) {
        document.getElementById("editResult").innerText = "❌ File not found.";
        document.getElementById("editForm").classList.add("hidden");
      } else {
        document.getElementById("editForm").classList.remove("hidden");
        document.getElementById("editName").value = file.file_name;
        document.getElementById("editAlmirah").value = file.almirah;
        document.getElementById("editShelf").value = file.shelf_code;
      }
    }

    function showEditPassword() {
      document.getElementById("editPasswordSection").classList.remove("hidden");
    }

    function saveEditedFile() {
      const pw = document.getElementById("editPassword").value;
      if (pw !== ADD_PASSWORD) {
        alert("❌ Incorrect password");
        return;
      }

      const code = document.getElementById("editSearch").value.trim();
      const data = loadData();
      const index = data.findIndex(f => f.file_code === code);
      if (index === -1) return;

      data[index].file_name = document.getElementById("editName").value.trim();
      data[index].almirah = document.getElementById("editAlmirah").value.trim();
      data[index].shelf_code = document.getElementById("editShelf").value.trim();

      saveData(data);
      alert("✅ File updated.");
      document.getElementById("editPasswordSection").classList.add("hidden");
      renderFiles();
    }

    function showDeletePassword() {
      document.getElementById("deletePasswordSection").classList.remove("hidden");
    }

    function confirmDeleteFile() {
      const pw = document.getElementById("deletePassword").value;
      if (pw !== DELETE_PASSWORD) {
        alert("❌ Incorrect password");
        return;
      }

      const code = document.getElementById("deleteCode").value.trim();
      let data = loadData();
      const originalLength = data.length;
      data = data.filter(f => f.file_code !== code);
      if (data.length === originalLength) {
        document.getElementById("deleteResult").innerText = "❌ File not found.";
      } else {
        saveData(data);
        document.getElementById("deleteResult").innerText = "✅ File deleted.";
        renderFiles();
      }
    }

    function renderFiles() {
      const fileList = document.getElementById("fileList");
      const sortBy = document.getElementById("sortBy").value;
      const filterAlmirah = document.getElementById("filterAlmirah").value;
      const filterShelf = document.getElementById("filterShelf").value;

      let data = loadData();

      if (filterAlmirah) {
        data = data.filter(f => f.almirah === filterAlmirah);
      }
      if (filterShelf) {
        data = data.filter(f => f.shelf_code === filterShelf);
      }

      if (sortBy === "almirah") {
        data.sort((a, b) => a.almirah.localeCompare(b.almirah));
      } else if (sortBy === "shelf") {
        data.sort((a, b) => a.shelf_code.localeCompare(b.shelf_code));
      }

      fileList.innerHTML = data.map(f =>
        `<div class="file-block">
        <strong>${f.file_name}</strong> (Code: ${f.file_code})<br>
        Almirah: ${f.almirah} | Shelf: ${f.shelf_code}
      </div>`).join("");

      updateFilters(data);
    }

    function updateFilters(data) {
      const almirahs = [...new Set(loadData().map(f => f.almirah))];
      const shelves = [...new Set(loadData().map(f => f.shelf_code))];

      const almirahFilter = document.getElementById("filterAlmirah");
      const shelfFilter = document.getElementById("filterShelf");

      almirahFilter.innerHTML = '<option value="">Filter by Almirah</option>' +
        almirahs.map(a => `<option value="${a}">${a}</option>`).join("");
      shelfFilter.innerHTML = '<option value="">Filter by Shelf</option>' +
        shelves.map(s => `<option value="${s}">${s}</option>`).join("");
    }

    function printFiles() {
      const data = loadData();
      const win = window.open("", "_blank");
      win.document.write("<h2>📄 File Records</h2>");
      win.document.write(data.map(f =>
        `<p><strong>${f.file_name}</strong> (Code: ${f.file_code})<br>Almirah: ${f.almirah} | Shelf: ${f.shelf_code}</p>`
      ).join(""));
      win.document.close();
      win.print();
    }

    function exportData() {
      const dataStr = JSON.stringify(loadData(), null, 2);
      const blob = new Blob([dataStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "file_data.json";
      a.click();
    }

    function importData(e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function (event) {
        const newData = JSON.parse(event.target.result);
        saveData(newData);
        alert("✅ Data imported.");
        renderFiles();
      };
      reader.readAsText(file);
    }

    window.onload = renderFiles;